#include "receiver.h"
#include "map.h"
#include <vector>
#include <cassert>
#include <iostream>
using namespace std;

class stock_hist{
    public:
    int last_transaction, highest_buy, lowest_sell;
    stock_hist(){
        last_transaction = 0;
        highest_buy = -1;
        lowest_sell = INT32_MAX;
    }
};

class order_2{
    public:
        int order_index = 0;vector<int> trans_org;vector<int> trans_buy;int buy_money = 0;int org_money = 0;string policy;string original;
        order_2(int capacity){
            for(int index = 0; index < capacity; index++){
                trans_org.push_back(0);
            }
        }
};

class order_3{
    public:
        int order_index = 0;vector<int> trans_org;vector<int> trans_buy;int buy_money = 0;int org_money = 0;int quantity = 0;string policy;string original;
        order_3(int capacity){
            for(int index = 0; index < capacity; index++){
                trans_org.push_back(0);
            }
        }
};

//Globally declared to save space in function calling for part2
vector<string> company_indices_2;
int total_end_profit_2 = 0;
vector<int> arbit_check_2;
vector<int> max_arbit_indices_2;
int max_price_2 = INT32_MIN;
vector<int> arbit_indices_2;
int price_2 = 0;

//Globally declared to save space in function calling for part3
vector<string> company_indices_3;
int total_end_profit_3 = 0;
vector<int> arbit_check_3;
vector<pair<int,int>> max_arbit_indices_3; // 1st:index, 2nd:number of stocks
int max_price_3 = INT32_MIN;
vector<pair<int,int>> arbit_indices_3;
int price_3 = 0;

void run_Arbitrage_2(vector<order_2>& easy, int index){
    arbit_indices_2.push_back(index);
    for(int i = 0;i < arbit_check_2.size();i++){
        arbit_check_2[i] += easy[index].trans_buy[i];
    }
    price_2 += easy[index].buy_money;
    if(index >= easy.size()-1){
        arbit_indices_2.pop_back();
        price_2 -= easy[index].buy_money;
        for(int i = 0;i < arbit_check_2.size();i++){
            arbit_check_2[i] -= easy[index].trans_buy[i];
        }
        return;
    }
    int found = 1;
    for(auto i: arbit_check_2){
        if(i != 0){found = 0; break;}
    }
    if(found){
        if(price_2 > max_price_2){
            max_price_2 = price_2;
            max_arbit_indices_2 = arbit_indices_2;
        }
        arbit_indices_2.pop_back();
        price_2 -= easy[index].buy_money;
        for(int i = 0;i < arbit_check_2.size();i++){
            arbit_check_2[i] -= easy[index].trans_buy[i];
        }
        return;
    }
    for(int i = index+1; i<easy.size()-1;i++){
        run_Arbitrage_2(easy,i);
    }
    arbit_indices_2.pop_back();
    price_2 -= easy[index].buy_money;
    for(int i = 0;i < arbit_check_2.size();i++){
        arbit_check_2[i] -= easy[index].trans_buy[i];
    }
    return;
}

void check_Arbitrage_2(vector<order_2>& easy){
    // Printing to terminal and changing of easy is done inside itself
    arbit_check_2 = easy[easy.size()-1].trans_buy;
    price_2 += easy[easy.size()-1].buy_money;
    for(int i=0;i<easy.size()-1;i++){
        run_Arbitrage_2(easy,i);
    }
    if(max_price_2 <= 0){
        cout << "No Trade" << endl;
    }
    else if(max_price_2>0){
        total_end_profit_2 += max_price_2;
        // Here Arbitrage is found and output is being formed
        string output = "";
        max_arbit_indices_2.push_back(easy.size()-1);
        reverse(max_arbit_indices_2.begin(),max_arbit_indices_2.end());
        for(auto index: max_arbit_indices_2){
            output += easy[index].original;
            output += to_string(easy[index].org_money);output+=" ";
            if(easy[index].policy=="s"){output+="b";}
            else{output+="s";}
            cout << output << endl;
            output = "";
        }
        // Erasing used transactions from easy
        for(auto index: max_arbit_indices_2){
            easy.erase(easy.begin()+index);
        }
    }
    // Bringing Global variables to default values for later use
    arbit_check_2.clear();max_arbit_indices_2.clear();arbit_indices_2.clear();max_price_2 = INT32_MIN;price_2 = 0;
}

void run_Arbitrage_3(vector<order_3>& easy, int index){
    for(int num_stock = 1; num_stock <= easy[index].quantity;num_stock++){
        arbit_indices_3.push_back(make_pair(index,num_stock));
        for(int i = 0;i < arbit_check_3.size();i++){
            arbit_check_3[i] += easy[index].trans_buy[i]*num_stock;
        }
        price_3 += easy[index].buy_money*num_stock;
        if(index >= easy.size()-1){
            arbit_indices_3.pop_back();
            price_3 -= easy[index].buy_money*num_stock;
            for(int i = 0;i < arbit_check_3.size();i++){
                arbit_check_3[i] -= easy[index].trans_buy[i]*num_stock;
            }
            return;
        }
        int found = 1;
        for(auto& i: arbit_check_3){
            if(i != 0){found = 0; break;}
        }
        if(found){
            if(price_3 > max_price_3){
                max_price_3 = price_3;
                max_arbit_indices_3 = arbit_indices_3;
            }
            arbit_indices_3.pop_back();
            price_3 -= easy[index].buy_money*num_stock;
            for(int i = 0;i < arbit_check_3.size();i++){
                arbit_check_3[i] -= easy[index].trans_buy[i]*num_stock;
            }
            continue;
        }
        for(int i = index+1; i<easy.size();i++){
            // cout << index << endl;
            run_Arbitrage_3(easy,i);
        }
        arbit_indices_3.pop_back();
        price_3 -= easy[index].buy_money*num_stock;
        for(int i = 0;i < arbit_check_3.size();i++){
            arbit_check_3[i] -= easy[index].trans_buy[i]*num_stock;
        }
    }
    return;
}

void check_Arbitrage_3(vector<order_3>& easy){
    // Printing to terminal and changing of easy is done inside itself 
    int max_price1 = INT32_MIN;int numstock_max = 0;
    for(int num_stock = 1;num_stock <= easy[easy.size()-1].quantity;num_stock++){
        price_3 = easy[easy.size()-1].buy_money*num_stock;
        arbit_check_3.clear();
        arbit_check_3 = easy[easy.size()-1].trans_buy;
        for(int i=0;i< easy[easy.size()-1].trans_buy.size();i++){
            arbit_check_3[i] = easy[easy.size()-1].trans_buy[i]*num_stock; 
            // cout << i.first << " " << arbit_check[i.first] << " ";
        }
        // cout << endl;
        for(int i=0;i<easy.size()-1;i++){
            run_Arbitrage_3(easy,i);
        }
        if(max_price_3 > max_price1){
            numstock_max = num_stock;max_price1 = max_price_3;
        }
    }
    if(max_price_3 <= 0){
        cout << "No Trade" << endl;
    }
    else if(max_price_3>0){
        total_end_profit_3 += max_price_3;
        // Here Arbitrage is found and output is being formed
        string output = "";
        max_arbit_indices_3.push_back(make_pair(easy.size()-1,numstock_max));
        reverse(max_arbit_indices_3.begin(),max_arbit_indices_3.end());
        for(auto& index: max_arbit_indices_3){
            output += easy[index.first].original;
            output += to_string(easy[index.first].org_money);output+=" ";
            output += to_string(index.second);output+=" ";
            if(easy[index.first].policy=="s"){output+="b";}
            else{output+="s";}
            cout << output << endl;
            output = "";
        }
        // Editing used transactions from easy
        for(auto& index: max_arbit_indices_3){
            easy[index.first].quantity -= index.second;
            if(easy[index.first].quantity == 0){easy.erase(easy.begin()+index.first);}
        }
    }
    // Bringing Global variables to default values for later use
    arbit_check_3.clear();max_arbit_indices_3.clear();arbit_indices_3.clear();max_price_3 = INT32_MIN;price_3 = 0;
}

int main(int argc, char *argv[]){
    int arg1 = std::atoi(argv[1]);
    if (arg1 == 1) {
        Map<string,stock_hist> curr_price;
        string s = "";
        string r_13 = "";
        r_13 += char(13);
        vector<string> ordertable;
        Receiver rcv;
        bool dollarfound = false;
        while(!dollarfound){
            std::string message = rcv.readIML();
            message = s + message;
            ordertable.clear();
            if(message.find("$") != string::npos){dollarfound = true;}
            int index=0;
            s = "";
            for(auto& i:message){
                if(i == 13 || i == 36){
                    ordertable.push_back(s);
                    s="";
                    continue;
                }
                if(i == 36){
                    dollarfound = true;
                    continue;
                }
                s += i; 
            }
            for(auto& message: ordertable){
                if(message == "\0" || message == r_13) continue;
                string stock;string med;string order;
                int index = 0;
                while(message[index]!= ' '){    //stock name
                    stock+=message[index];
                    index++;
                }
                index++;
                while(message[index]!= ' '){    //sell or buy
                    med+=message[index];
                    index++;
                }
                int price = stoi(med);
                index++;
                order += message[index];
                if(!curr_price.search(stock)){
                    curr_price[stock].last_transaction = price;
                    if(order == "s"){
                        message.clear();
                        message = stock + ' ' + med + ' ' + 'b';
                        cout << message << endl;
                        continue;
                    }
                    if(order == "b"){
                        message.clear();
                        message = stock + ' ' + med + ' ' + 's';
                        cout << message << endl;
                        continue;
                    }
                }
                else if(order == "s"){
                    if(price >= curr_price[stock].lowest_sell){
                        message = "No Trade";
                        cout << message << endl;
                        continue;
                    }
                    else if(price < curr_price[stock].lowest_sell){
                        curr_price[stock].lowest_sell = price;
                        if(curr_price[stock].lowest_sell == curr_price[stock].highest_buy){
                            curr_price[stock].highest_buy = -1;
                            curr_price[stock].lowest_sell = INT32_MAX;
                            message = "No Trade";
                            cout << message << endl;
                            continue;
                        }
                        else if(price < curr_price[stock].last_transaction){
                            curr_price[stock].lowest_sell = INT32_MAX;
                            curr_price[stock].last_transaction = price;
                            message.clear();
                            message = stock + ' ' + med + ' ' + 'b';
                            cout << message << endl;
                            continue;
                        }
                        else{
                            message = "No Trade";
                            cout << message << endl;
                            continue;
                        } 
                    } else {
                        message = "No Trade";
                        cout << message << endl;
                        continue;
                    }
                }
                else if(order == "b"){
                    if(price <= curr_price[stock].highest_buy){
                        message = "No Trade";
                        cout << message << endl;
                        continue;
                    }
                    else if(price > curr_price[stock].highest_buy){
                        curr_price[stock].highest_buy = price;
                        if(curr_price[stock].lowest_sell == curr_price[stock].highest_buy){
                            curr_price[stock].highest_buy = -1;
                            curr_price[stock].lowest_sell = INT32_MAX;
                            message = "No Trade";
                            cout << message << endl;
                            continue;
                        }
                        else if(price > curr_price[stock].last_transaction){
                            curr_price[stock].highest_buy = -1;
                            curr_price[stock].last_transaction = price;
                            message.clear();
                            message = stock + ' ' + med + ' ' + 's';
                            cout << message << endl;
                            continue;
                        }
                        else{
                            message = "No Trade";
                            cout << message << endl;
                            continue;
                        }
                    }
                
                
                }

            }
        }
        rcv.terminate();
    } else if (arg1 == 2) {
        int sequence = 0;
        Receiver rcv;
        vector<string> ordertable;
        vector<order_2> easy;
        string s;
        string left_over = "";
        bool dollarfound = false;
        while(!dollarfound){
            std::string message = rcv.readIML();
            message = left_over + message;
            ordertable.clear();
            // cout << message << endl;
            if(message.find("$") != string::npos){dollarfound = true;}
            int index=0;
            left_over = "";
        for(auto& i:message){
            int num = i;
            // cout << num << endl;
            if(num==-17 || num == -65 || num == -67){continue;}
            if(i == 13 || i == 36 || i==35){
                ordertable.push_back(s);
                s="";
                continue;
            }
            s += i; 
        }
        for(auto& message : ordertable){
            int index = 0;
            int reject = 0;
            string output = "";
            int not_all_0 = 1;
            int dont_check = 0;
            string stock_name = "";
            string quant = "";
            string original = "";
            order_2 curr(company_indices_2.size());curr.order_index = sequence; 
            sequence++;
            while(index<message.size()){
                // cout << message << endl;
                assert(!(message[index] == '-' || (message[index] >= 48 && message[index] <= 57)));
                while(message[index] != ' '){
                    int num = message[index];
                    stock_name += message[index];
                    // cout << num << endl;
                    index++;
                }
                index++;
                while(message[index] != ' '){
                    quant += message[index];
                    index++;
                }
                original += (stock_name + " " + quant + " " );
                // cout << stock_name << "'" << quant << endl;
                int quant_int = stoi(quant);
                int place = 0;
                if(quant_int !=0){
                    not_all_0 = 0;
                    for(; place < company_indices_2.size();place++){
                        if(company_indices_2[place] == stock_name){curr.trans_org[place] = quant_int; break;}
                    }
                    if(place == company_indices_2.size()){ // company is seen for the first time
                        dont_check = 1;
                        company_indices_2.push_back(stock_name);
                        curr.trans_org.push_back(quant_int);
                        for(auto &i : easy){
                            i.trans_buy.push_back(0);i.trans_org.push_back(0);
                        } 
                    }
                }
                // curr.trans_org[stock_name] = quant_int;
                index++;
                stock_name = "";quant = "";
                if(!(message[index] == '-' || (message[index] >= 48 && message[index] <= 57))){continue;}
                else{// for the money exchanged
                if(not_all_0 == 1){cout << "No Trade" << endl; break;}
                    curr.original = original;
                    while(message[index] != ' '){
                        quant += message[index];
                        index++;
                    }
                    curr.org_money = stoi(quant);
                    quant = "";
                    index++;
                    curr.policy = message[index];
                    //Cancellation policy
                    if(message[index] == 's'){
                        curr.buy_money=(-1)*curr.org_money;
                        curr.trans_buy = curr.trans_org;
                        for(int i = 0; i < curr.trans_org.size(); i++){
                            curr.trans_buy[i] =curr.trans_org[i]*(-1);
                        }
                    }
                    else if(message[index] == 'b'){
                        curr.buy_money = curr.org_money;
                        curr.trans_buy = curr.trans_org;
                    }

                    if(dont_check == 1){
                        cout << "No Trade" << endl;
                        easy.push_back(curr);
                        break;
                    }
                    if(curr.policy == "s"){
                        for(auto it = easy.begin();it<easy.end();it++){
                                if(it->trans_org == curr.trans_org && it->policy == "s"){
                                    if(it->org_money <= curr.org_money){
                                        reject = 1;
                                        break; // Still curr isn't added to the table, so no need to delete it
                                    }
                                    else if(it->org_money > curr.org_money){
                                        easy.erase(it);
                                        break;
                                    }
                                }
                        }
                        if(reject == 0){
                            for(auto it = easy.begin();it<easy.end();it++){
                                if(it->trans_org == curr.trans_org && it->policy == "b"){
                                    if(it->org_money == curr.org_money){
                                        easy.erase(it);
                                        reject = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if(curr.policy == "b"){
                        for(auto it = easy.begin();it<easy.end();it++){
                                if(it->trans_org == curr.trans_org && it->policy == "b"){
                                    if(it->org_money >= curr.org_money){
                                        reject = 1;
                                        break; // Still curr isn't added to the table, so no need to delete it
                                    }
                                    else if(it->org_money < curr.org_money){
                                        easy.erase(it);
                                        break;
                                    }
                                }
                        }
                        if(reject == 0){
                            for(auto it = easy.begin();it<easy.end();it++){
                                if(it->trans_org == curr.trans_org && it->policy == "s"){
                                    if(it->org_money == curr.org_money){
                                        easy.erase(it);
                                        reject = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if(reject){
                        cout << "No Trade" << endl;
                        break;
                    }

                    else{
                        easy.push_back(curr);
                        // Find Arbitrage
                        check_Arbitrage_2(easy);
                        break;  

                    }
                }
            }
        }
        }
        rcv.terminate();
        // Careful below line should also be out of the bigger for loop once we change the input access method.
        cout << total_end_profit_2;
    } else if (arg1 == 3) {
        int sequence = 0;
        Receiver rcv;
        vector<string> ordertable;
        vector<order_3> easy;
        string s;

        string left_over = "";
        bool dollarfound = false;
        while(!dollarfound){
            std::string message = rcv.readIML();
            message = left_over + message;
            ordertable.clear();
            // cout << message << endl;
            if(message.find("$") != string::npos){dollarfound = true;}
            int index=0;
            left_over = "";
        for(auto& i:message){
            int num = i;
            // cout << num << endl;
            if(num==-17 || num == -65 || num == -67){continue;}
            if(i == 13 || i == 36 || i==35){
                ordertable.push_back(s);
                s="";
                continue;
            }
            s += i; 
        }
        for(auto& message : ordertable){
            int index = 0;
            int reject = 0;
            string output = "";
            string stock_name = "";
            string quant = "";
            string original = "";
            order_3 curr(company_indices_3.size());curr.order_index = sequence; 
            sequence++;
            while(index<message.size()){
                assert(!(message[index] == '-' || (message[index] >= 48 && message[index] <= 57)));
                while(message[index] != ' '){ // reading stock name
                    int num = message[index];
                    stock_name += message[index];
                    index++;
                }
                index++;
                while(message[index] != ' '){ // reading stock quantity
                    quant += message[index];
                    index++;
                }
                original += (stock_name + " " + quant + " " );
                int quant_int = stoi(quant);
                int place = 0;
                for(; place < company_indices_3.size();place++){
                    if(company_indices_3[place] == stock_name){curr.trans_org[place] = quant_int; break;}
                }
                if(place == company_indices_3.size()){ // company is seen for the first time
                    company_indices_3.push_back(stock_name);
                    curr.trans_org.push_back(quant_int);
                    for(auto& i : easy){
                        i.trans_buy.push_back(0);i.trans_org.push_back(0);
                    } 
                }
                index++;
                stock_name = "";quant = "";
                if(!(message[index] == '-' || (message[index] >= 48 && message[index] <= 57))){continue;}
                else{// for the money exchanged
                    curr.original = original;
                    while(message[index] != ' '){
                        quant += message[index];
                        index++;
                    }
                    curr.org_money = stoi(quant); // In part-3 this is for 1 stock
                    quant = "";
                    index++;
                    while(message[index] != ' '){ // For the whole quantity
                        quant += message[index];
                        index++;
                    }
                    curr.quantity = stoi(quant);
                    quant = "";
                    index++;
                    curr.policy = message[index];
                    //Cancellation policy
                    if(curr.policy == "s"){
                        for(auto it = easy.begin();it<easy.end();it++){
                            if(it->trans_org == curr.trans_org && it->policy == "s"){
                                if(it->org_money == curr.org_money){
                                    curr.quantity += it->quantity;
                                    easy.erase(it);
                                }
                            }
                        }
                        if(reject == 0){  // if condition is actually not required.(Continued from part 2.)
                            for(auto it = easy.begin();it<easy.end();it++){
                                if(it->trans_org == curr.trans_org && it->policy == "b"){
                                    if(it->org_money == curr.org_money){
                                        if(it->quantity > curr.quantity){
                                            it->quantity -= curr.quantity;
                                            reject = 1;
                                            break;
                                        }
                                        else if(it->quantity == curr.quantity){
                                            reject = 1;
                                            easy.erase(it);
                                            break;
                                        }
                                        else if(it->quantity < curr.quantity){
                                            curr.quantity -= it->quantity;
                                            easy.erase(it);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    else if(curr.policy == "b"){
                        for(auto it = easy.begin();it<easy.end();it++){
                            if(it->trans_org == curr.trans_org && it->policy == "b"){
                                if(it->org_money == curr.org_money){
                                    curr.quantity += it->quantity;
                                    easy.erase(it);
                                }
                            }
                        }
                        if(reject == 0){ // if condition is actually not required.(Continued from part 2.)
                            for(auto it = easy.begin();it<easy.end();it++){
                                if(it->trans_org == curr.trans_org && it->policy == "s" && it->org_money == curr.org_money){
                                    if(it->quantity > curr.quantity){
                                            it->quantity -= curr.quantity;
                                            reject = 1;
                                            break;
                                        }
                                        else if(it->quantity == curr.quantity){
                                            reject = 1;
                                            easy.erase(it);
                                            break;
                                        }
                                        else if(it->quantity < curr.quantity){
                                            curr.quantity -= it->quantity;
                                            easy.erase(it);
                                            break;
                                        }
                                }
                            }
                        }
                    }
                    if(reject){
                        cout << "No Trade" << endl;
                        break;
                    }

                    else{
                        if(message[index] == 's'){
                            curr.buy_money=(-1)*curr.org_money;
                            curr.trans_buy = curr.trans_org;
                            for(int i = 0; i < curr.trans_org.size(); i++){
                                curr.trans_buy[i] =curr.trans_org[i]*(-1);
                            }
                        }
                        else if(message[index] == 'b'){
                            curr.buy_money = curr.org_money;
                            curr.trans_buy = curr.trans_org;
                        }
                        easy.push_back(curr);
                        
                        // Find Arbitrage
                        check_Arbitrage_3(easy);
                        break;  

                    }
                }
            }
        }
        }
        rcv.terminate();
        // Careful below line should also be out of the bigger for loop once we change the input access method.
        cout << total_end_profit_3 << endl;
    }
    return 0;
}
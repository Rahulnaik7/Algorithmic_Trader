#include "market.h"
#include "heap.h"
#include <iostream>
#include <map>
#include <string>
#include <fstream>
using namespace std;

/*
1) At an instant if some trade is done btw. the same 2 traders twice due to the way it is stored in the heap, i am printing int differently;
   
*/
market::market(int argc, char** argv)
{
	input_file.open("output.txt");
}

bool correct_output(string order){
    //checking if timestamp is integer
    // return 1;
    int index = 0;
    int single_stock = 0;
    if(order.size() == 0){return false;}
    if(order[index] == ' '){return false;}
    while(order[index]!=' ' && index < order.size()){
        if(order[index] < 48 || order[index] > 57){return false;}
        index++;
        if(index == order.size()){return false;}
    }
    index++;
    // Expecting trader name
    if(index == order.size() || order[index] == ' '){return false;}
    while(order[index]!=' ' && index < order.size()){
        if(!((order[index] >= 48 && order[index] <= 57) || (order[index] >= 65 && order[index] <= 90) || (order[index] >= 97 && order[index] <= 122))){return false;}
        index++;
        if(index == order.size()){return false;}
    }
    index++;
    //Expecting SELL/BUY
    if(index == order.size() || order[index] == ' '){return false;}
    if(order[index] == 'S' && order[index+1] == 'E' && order[index+2] == 'L' && order[index+3] == 'L'){index=index+4;}
    else if(order[index] == 'B' && order[index+1] == 'U' && order[index+2] == 'Y'){index = index+3;}
    else{return false;}
    if(order[index] != ' '){return false;}
    index++;
    //Now we expect Stock name
    if(index == order.size() || order[index] == ' '){return false;}
    while(order[index]!=' ' && index < order.size()){
        if(!((order[index] >= 65 && order[index] <= 90) || (order[index] >= 97 && order[index] <= 122))){return false;}
        index++;
        if(index == order.size()){return false;}
    }
    index++;
    if(index == order.size() || order[index] == ' '){return false;}
    // checking if its a single_stock order;
    if(order[index] == '$'){single_stock = 1;}
    // If its not single_stock checking if the sequence is stock-number-stock-number-...
    if(single_stock == 0){
        while(true){
            while(order[index]!=' ' && index < order.size()){
                if(order[index] < 48 || order[index] > 57){return false;}
                index++;
                if(index == order.size()){return false;}
            }
            index++;
            if(order[index] == ' ' || index == order.size()){return false;}
            if(order[index] == '$'){break;} // index is now pointing to $; till here everything is ok; continue from price now
            while(order[index]!=' ' && index < order.size()){
                if(!((order[index] >= 65 && order[index] <= 90) || (order[index] >= 97 && order[index] <= 122))){return false;}
                index++;
                if(index == order.size()){return false;}
            }
            index++;
            if(order[index] == ' ' || index == order.size()){return false;}
        }
    }
    //If above things are passed index now points to "$";
    if(order[index] != '$'){return false;}
    index++;
    if(order[index] == ' ' || index == order.size()){return false;}
    while(order[index]!=' ' && index < order.size()){
        if(order[index] < 48 || order[index] > 57){return false;}
        index++;
        if(index == order.size()){return false;}
    }
    index++;
    //Now quantity starting with #
    if(order[index] != '#' || index == order.size()){return false;}
    index++;
    if(order[index] == ' ' || index == order.size()){return false;}
    while(order[index]!=' ' && index < order.size()){
        if(order[index] < 48 || order[index] > 57){return false;}
        index++;
        if(index == order.size()){return false;}
    }
    index++;
    //Now expiry_time_duration
    if(order[index] == ' ' || index == order.size()){return false;}
    if(order[index] == '-' && order[index+1] == '1'){
        if(index+2 == order.size()){return true;}
        else{return false;}
    }
    while(order[index]!=' ' && index < order.size()){
        // cout << order[index] << endl;
        if(order[index] < 48 || order[index] > 57){
            // cout << "yes" << endl;
            return false;}
        index++;
        if(index == order.size()-1){return true;}
    }

    return true;
}

void market::start()
{   
    string order;
    int time = INT32_MIN;
    int total_money = 0,total_trade = 0,total_share = 0;
    // int time = 0;
    vector<string> company_indices;
    vector<heap> history; // string has stock_name + " " + SELL/BUY
    vector<string> player_name;
    vector<track> player;
    getline(input_file,order); // to remove TL
    while(getline(input_file,order) && order[0] != '!'){
        // cout << order << endl;
        bool check = correct_output(order);
        // cout << check << endl;
        if(check == false){continue;}
        int index = 0,index1 = 0;
        string st_time = "";
        while(order[index] != ' '){
            st_time += order[index];
            index++;
        }
        int start_time = stoi(st_time);
        // cout << start_time << endl;
        index++;
        string name = "";
        while(order[index] != ' '){
            name += order[index];
            index++;
        }
        index++;
        // cout << name << endl;
        string trans = "";
        while(order[index]!=' '){
            trans+=order[index];
            index++;
        }
        index++;
        string stock = "",stock1 = "";
        index1 = index;            // While editing be careful with index1 and index.
        while(order[index1] != ' '){
            stock1 += order[index1];
            index1++;
        }
        index1++;
        if(order[index1] == 1 && order[index1 + 1] == ' ' && order[index1+2] == '$'){ // ASML 1 type of stocks
            stock = stock1;
            index = index1+2;
        }
        else if(order[index1] == '$'){ // for just ASML type
            stock = stock1;
            index = index1;
        }
        else{   
            // cout << "yes" << endl;
            // while(order[index+1] != '$'){
            //     stock+=order[index];
            //     index++;
            // }
            vector<string> stock_ordering;
            while(true){
                string each_stock;
                while(order[index] != ' '){
                    each_stock += order[index];
                    index++;
                }
                each_stock += order[index];
                index++;
                while(order[index] != ' '){
                    each_stock += order[index];
                    index++;
                }
                index++;
                if(order[index]!= '$'){each_stock += " ";}
                stock_ordering.push_back(each_stock);
                if(order[index] == '$'){break;}
            }
            sort(stock_ordering.begin(),stock_ordering.end());
            for(auto i : stock_ordering){
                stock += i;
            }
            // cout << stock << endl;
        }
        // cout << trans << endl;
        // cout << stock << endl;
        index++; // 2 times to move past $ sign
        string pr = "";
        while(order[index]!=' '){
            pr+=order[index];
            index++;
        }
        int price = stoi(pr);
        index++;index++; // moving past #
        string qua = "";
        while(order[index]!=' '){
            qua+=order[index];
            index++;
        }
        // cout << "yes" << endl;
        int quantity = stoi(qua);
        // cout << quantity << endl;
        index++;
        string duration = "";
        while(index < order.size()){
            duration+=order[index];
            // cout << "yes" << endl;
            index++;
        }
        int exp_time = start_time + stoi(duration);
        if(stoi(duration) == -1){
            exp_time = INT32_MAX;
        }
        order_info latest(start_time,price,quantity,exp_time,trans,name);
        // till above its taking order input of a line
        // cout << 1 << endl;
        if(start_time!=time){
            time = start_time;
            // cout << start_time << endl;
            for(auto& i: history){
                // cout << 1 << endl;
                i.refresh(time);
            }
            // cout << 1 << endl;
        }
        // cout << 1 << endl;
        // cout << "out" << endl;
        // cout << trans << endl;
        // adding into history
        string key = stock + " " + trans;
        if(trans == "SELL"){
            string inverse = stock + " " + "BUY";
            // cout << latest.name << inverse << endl;
            // cout << (history.find(inverse) == history.end()) << endl;
            bool found = false;int location_inverse = -1;int location_key = -1;
            for(int index = 0; index < company_indices.size();index++){
                if(company_indices[index] == inverse){found = true;location_inverse = index;}
            }
            if(!found){
            // if(!history.search(inverse)){
                // cout << 1 << endl;
                for(int index = 0; index < company_indices.size();index++){
                    if(company_indices[index] == key){location_key = index;}
                }
                if(location_key != -1){history[location_key].insert(latest);}
                else{
                    company_indices.push_back(key);
                    heap x;
                    history.push_back(x);
                    location_key = history.size()-1;
                    history[location_key].insert(latest);
                    }
                // cout << "yes" << endl;
            }
            else{
                while(latest.quantity > 0 && history[location_inverse].orders.size() > 0 && history[location_inverse].orders[0].price >= price){
                    // cout << "yes" << endl;
                    int trans_quantity = 0;
                    string buyer_name = history[location_inverse].orders[0].name;
                    int trans_price = history[location_inverse].orders[0].price;
                    // for(auto i: history[inverse].orders){
                    //     cout << i.name << " : " << i.price;
                    // }
                    // int trans_price = latest.price;
                    if(history[location_inverse].orders[0].quantity > latest.quantity){
                        trans_quantity = latest.quantity;
                        history[location_inverse].orders[0].quantity -= latest.quantity;
                        latest.quantity = 0;
                    }
                    else{
                        trans_quantity = history[location_inverse].orders[0].quantity;
                        latest.quantity -= history[location_inverse].orders[0].quantity;
                        history[location_inverse].orders[0].quantity = 0;
                        // cout << "yes3" << endl;
                        history[location_inverse].delete_max();
                        // cout << "yes3" << endl;
                    }
                    int present_index = -1;int opp_index = -1;
                    for(int index = 0; index < player_name.size();index++){
                        if(player_name[index] == name){present_index = index;}
                        if(player_name[index] == buyer_name){opp_index = index;}
                    }
                    if(present_index == -1){player_name.push_back(name);track x;player.push_back(x);present_index = player_name.size()-1;}
                    if(opp_index == -1){player_name.push_back(buyer_name);track x;player.push_back(x);opp_index = player_name.size()-1;}
                    player[present_index].sell += trans_quantity;
                    player[opp_index].buy += trans_quantity;
                    player[present_index].money += trans_quantity*trans_price;
                    player[opp_index].money -= trans_quantity*trans_price;
                    total_money += trans_quantity*trans_price;
                    total_trade += 1;
                    total_share += trans_quantity;
                    cout << buyer_name + " purchased " + to_string(trans_quantity) +" share of " +stock + " from " + name + " for $" + to_string(trans_price) +"/share\n";
                }
                if(latest.quantity > 0){
                    // cout << "yes4" << endl;
                    for(int index = 0; index < company_indices.size();index++){
                        if(company_indices[index] == key){location_key = index;}
                    }
                    if(location_key != -1){history[location_key].insert(latest);}
                    else{
                        company_indices.push_back(key);
                        heap x;
                        history.push_back(x);
                        location_key = history.size()-1;
                        history[location_key].insert(latest);
                        }
                    // cout << "yes4" << endl;
                }
            }
            // cout << "yes" << endl;
        }
        else if(trans == "BUY"){
            string inverse = stock + " " + "SELL";
            // cout << latest.name << inverse << endl;
            bool found = false;int location_inverse = -1;int location_key = -1;
            for(int index = 0; index < company_indices.size();index++){
                if(company_indices[index] == inverse){found = true;location_inverse = index;}
            }
            if(!found){
            // if(!history.search(inverse)){
                // cout << 1 << endl;
                for(int index = 0; index < company_indices.size();index++){
                    if(company_indices[index] == key){location_key = index;}
                }
                if(location_key != -1){history[location_key].insert(latest);}
                else{
                    company_indices.push_back(key);
                    heap x;
                    history.push_back(x);
                    location_key = history.size()-1;
                    history[location_key].insert(latest);
                    }
                // cout << "yes" << endl;
            }
            else{
                while(latest.quantity > 0 && history[location_inverse].orders.size() > 0 && history[location_inverse].orders[0].price <= price){
                    // cout << "yes" << endl;
                    int trans_quantity = 0;
                    string buyer_name = history[location_inverse].orders[0].name;
                    int trans_price = history[location_inverse].orders[0].price;
                    // int trans_price = latest.price;
                    if(history[location_inverse].orders[0].quantity > latest.quantity){
                        trans_quantity = latest.quantity;
                        history[location_inverse].orders[0].quantity -= latest.quantity;
                        latest.quantity = 0;
                    }
                    else{
                        trans_quantity = history[location_inverse].orders[0].quantity;
                        latest.quantity -= history[location_inverse].orders[0].quantity;
                        history[location_inverse].orders[0].quantity = 0;
                        // cout << "yes1" << endl;
                        history[location_inverse].delete_max();
                        // cout << "yes1" << endl;
                    }
                    int present_index = -1;int opp_index = -1;
                    for(int index = 0; index < player_name.size();index++){
                        if(player_name[index] == name){present_index = index;}
                        if(player_name[index] == buyer_name){opp_index = index;}
                    }
                    if(present_index == -1){player_name.push_back(name);track x;player.push_back(x);present_index = player_name.size()-1;}
                    if(opp_index == -1){player_name.push_back(buyer_name);track x;player.push_back(x);opp_index = player_name.size()-1;}
                    player[present_index].buy += trans_quantity;
                    player[opp_index].sell += trans_quantity;
                    player[present_index].money -= trans_quantity*trans_price;
                    player[opp_index].money += trans_quantity*trans_price;
                    total_money += trans_quantity*trans_price;
                    total_trade += 1;
                    total_share += trans_quantity;
                    cout << name + " purchased " + to_string(trans_quantity) +" share of " +stock + " from " + buyer_name + " for $" + to_string(trans_price) +"/share\n";
                }
                if(latest.quantity > 0){
                    // cout << "yes2" << endl;
                    for(int index = 0; index < company_indices.size();index++){
                        if(company_indices[index] == key){location_key = index;}
                    }
                    if(location_key != -1){history[location_key].insert(latest);}
                    else{
                        company_indices.push_back(key);
                        heap x;
                        history.push_back(x);
                        location_key = history.size()-1;
                        history[location_key].insert(latest);
                        }
                    // cout << "yes2" << endl;
                }
            }
        }
        // cout << "yes" << endl;
    }
	cout << endl << "---End of Day---" << endl;
    cout << "Total Amount of Money Transferred: $" << total_money <<endl;
    cout << "Number of Completed Trades: " << total_trade << endl ;
    cout << "Number of Shares Traded: " <<  total_share << endl ;
    for(int index =0;index < player_name.size();index++){
        cout << player_name[index] << " bought " << player[index].buy << " and sold " << player[index].sell << " for a net transfer of $" << player[index].money << endl; 
    }    
}

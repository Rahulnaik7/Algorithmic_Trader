#include <iostream>
#include <vector>
#include <string>
using namespace std;

class track{
    public:
        int sell = 0, buy = 0, money = 0; 
};
class order_info{ // use only > while comparing
    public:
    int start_time = 0,price = 0, quantity = 0, exp_time = 0;string order;string name; // order = SELL or BUY
    order_info(int i1,int i2,int i3,int i4,string h,string n){
        start_time = i1; price = i2; quantity = i3;exp_time = i4;order = h;name = n;
    }
    bool operator>(order_info other){
        if(order == "SELL"){
            if(price < other.price){return true;}
            else if(price > other.price){return false;}
            else if(price == other.price){
                if(start_time < other.start_time){return true;}
                else if(start_time > other.start_time){return false;}
                else if(start_time == other.start_time){
                    // if(exp_time == -1){return false;}
                    // else if(other.exp_time == -1){return true;}
                    // else if(exp_time < other.exp_time){return true;}
                    // else if(exp_time > other.exp_time){return false;}
                    // else if(exp_time == other.exp_time){
                        if(name < other.name){return true;}
                        else {return false;}
                    // }
                }
            }
        }
        else if(order == "BUY"){
            if(price > other.price){return true;}
            else if(price < other.price){return false;}
            else if(price == other.price){
                if(start_time < other.start_time){return true;}
                else if(start_time > other.start_time){return false;}
                else if(start_time == other.start_time){
                    // if(exp_time == -1){return false;}
                    // else if(other.exp_time == -1){return true;}
                    // else if(exp_time < other.exp_time){return true;}
                    // else if(exp_time > other.exp_time){return false;}
                    // else if(exp_time == other.exp_time){
                        if(name < other.name){return true;}
                        else {return false;}
                    // }
                }
            }
        }
        return false;
    }

    order_info& operator=(const order_info& other){
        if(&other == this){
            return *this;
        }

        start_time = other.start_time;
        price = other.price;
        quantity = other.quantity;
        exp_time = other.exp_time;
        order = other.order;
        name = other.name;

        return *this;
    }
};

class heap{
    public:
        vector<order_info> orders;
        void insert(order_info order){ // Making heap
            // size+=1;
            orders.push_back(order);
            int child = orders.size()-1;int parent;
            if(child%2){parent = (child-1)/2;}
            else{parent = child/2 - 1;}
            while(parent>=0){
                // cout << parent << endl;
                if(orders[child] > orders[parent]){
                    // for(auto i: orders){
                    //     cout << i.price << endl;
                    // }
                    // cout << orders[child].name << " lllll " << orders[child].price << endl;
                    order_info temp = orders[parent];
                    orders[parent] = orders[child];
                    orders[child] = temp;
                    child = parent;
                    if(child%2){parent = (child-1)/2;}
                    else{parent = child/2 - 1;}
                } else {
                    break;
                }
            }
            // for(auto i: orders){
            //     if(i.order == "BUY")
            //     cout << i.name << " :& "<< i.price << endl;
            // }
        }
        void delete_max(){
            if(orders.size() == 0){return;}
            order_info temp = orders[0];
            orders[0] = orders[orders.size()-1];
            orders[orders.size()-1] =temp; // Swapping greatest and least element
            orders.pop_back();
            if(orders.size() == 0){return;} 
            int parent = 0;
            while(true){
                int child1 = 2*parent+1,child2 = 2*parent+2;
                if(child1 >= orders.size()){break;}
                else if(child1 == orders.size()-1){
                    if(orders[child1] > orders[parent]){
                        order_info temp = orders[parent];
                        orders[parent] = orders[child1];
                        orders[child1] = temp;
                        parent = child1;
                        continue;
                    }
                    else{break;}
                }
                else{
                    int child = 0;
                    if(orders[child1] > orders[child2]){child = child1;}
                    else{child = child2;}
                    if(orders[child] > orders[parent]){
                        order_info temp = orders[parent];
                        orders[parent] = orders[child];
                        orders[child] = temp;
                        parent = child;
                        continue;
                    }
                    else{break;}
                }
            }
            // heapify(0);
        }
        void mySwap(int a, int b){
            // cout << "came to swap" << endl;
            order_info temp = orders[a];
            orders[a] = orders[b];
            orders[b] = temp;
        }
        void heapify(int index){
            // cout << index << " : 1000"<< endl;
            int left = 2*index + 1;
            int right = 2*index + 2;

            int min = index;
            if(left < orders.size() && orders[left] > orders[min]) {min = left;}
            if(right < orders.size() && orders[right] > orders[min]) {min = right;}

            if(min == index) return;
            mySwap(index, min);
            heapify(min);

        }
        void refresh(int time){
            // cout << time << endl;
            int n = orders.size() - 1;
            if(n == -1) return;
            for(int index = n;index>=0;index--){
                if(orders[index].exp_time < time){
                    if(index == orders.size() - 1){
                        orders.pop_back();
                    } else if(index < orders.size() - 1){
                        mySwap(index, orders.size() - 1);
                        orders.pop_back();
                        heapify(index);
                    }
                }
            }
            for(int index = orders.size()-1; index >= 0; index--){
                heapify(index);
            }
        }
};
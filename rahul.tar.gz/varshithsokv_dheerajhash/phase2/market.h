#ifndef MARKET_H
#define MARKET_H
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class market
{
public:
	ifstream input_file;
	market(int argc, char** argv);
	void start();
private:
};
#endif

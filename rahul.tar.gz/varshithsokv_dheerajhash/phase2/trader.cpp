// This is your trader. Place your orders from here
#include "map.h"
#include "new_heap.h"
#include <string>
#include <thread>
#include <fstream>
#include <atomic>
#include <mutex>
#include <iostream>
using namespace std;

extern std::atomic<int> commonTimer;
extern std::mutex printMutex;
const int NUM_STEPS = 100000;
int counter = 0;
int line_number = 0;
int last_line_number = 0;
std::ifstream inputFile("output.txt");
vector<string> myList;
string client_name = "22b0935_22b0907";
int last_time = 0;
Map<string,stock_info> stock_list;

int reader(int time)
{
    // Perform some work based on the current time
    std::string line;

        while (true) {
            if (std::getline(inputFile, line)) {
                // std::lock_guard<std::mutex> printLock(printMutex);
                // std::cout << line_number << line << std::endl;
                // line_number++;
                // cout << 1 << endl;
                if (line == "!@"){
                    // cout << 1 << endl;
                    for(auto& i: myList){
                        std::lock_guard<std::mutex> lock(printMutex);
                        cout << i << endl;
                    }
                    return 1;
                }
                if (line != "TL" && line != "" && line_number >= last_line_number) {
                    // std::lock_guard<std::mutex> myListLock(myListMutex);
                    // std::lock_guard<std::mutex> printLock(printMutex);
                    // std::cout << time << line << std::endl;
                    // line_number++;
                    // myList.push_back(line);
                    string order = line;
                    int index = 0;
                    string st_time = "";
                    while(order[index] != ' '){
                        st_time += order[index];
                        index++;
                    }
                    int start_time = stoi(st_time);
                    // cout << start_time << endl;
                    index++;
                    string name = "";
                    while(order[index] != ' '){
                        name += order[index];
                        index++;
                    }
                    index++;
                    // cout << name << endl;
                    string trans = "";
                    while(order[index]!=' '){
                        trans+=order[index];
                        index++;
                    }
                    index++;
                    string stock = "";
                    while(order[index+1] != '$'){
                        stock+=order[index];
                        index++;
                    }
                    // cout << trans << endl;
                    // cout << stock << endl;
                    index++;index++; // 2 times to move past $ sign
                    string pr = "";
                    while(order[index]!=' '){
                        pr+=order[index];
                        index++;
                    }
                    int price = stoi(pr);
                    index++;index++; // moving past #
                    string qua = "";
                    while(order[index]!=' '){
                        qua+=order[index];
                        index++;
                    }
                    // cout << "yes" << endl;
                    int quantity = stoi(qua);
                    // cout << quantity << endl;
                    index++;
                    string duration = "";
                    while(index < order.size()){
                        duration+=order[index];
                        // cout << "yes" << endl;
                        index++;
                    }
                    int exp_time = start_time + stoi(duration);
                    if(stoi(duration) == -1){
                        exp_time = INT32_MAX;
                    }
                    order_info_2 latest(start_time,price,quantity,exp_time,trans,name);
                    // cout << time << " " << client_name << " " << trans << " " << stock << " $" << to_string(price) << " #" << to_string(quantity) << " " << duration << endl; 

                    if(!stock_list.search(stock) || stock_list[stock].size() < 3){
                        stock_list[stock].insert(latest);
                        // cout << stock_list[stock].getMedian() << endl;
                        // cout << stock_list[stock].rightHeap.orders.size() << " " << client_name << " " << trans << " " << stock << " $" << to_string(price) << " #" << to_string(quantity) << " " << duration << endl; 
                        // line_number++;
                        // continue;
                    } else {
                        // cout << line << endl;
                        // line_number++;
                        if(trans == "SELL"){
                            if(price < stock_list[stock].getMedian()){
                                std::lock_guard<std::mutex> printLock(printMutex);
                                cout << time << " " << client_name << " " << "BUY" << " " << stock << " $" << to_string(price) << " #" << to_string(quantity) << " " << duration << endl;
                                line_number++;
                            }
                        } else if(trans == "BUY"){
                            std::lock_guard<std::mutex> printLock(printMutex);
                            if(price > stock_list[stock].getMedian()){
                                cout << time << " " << client_name << " " << "SELL" << " " << stock << " $" << to_string(price) << " #" << to_string(quantity) << " " << duration << endl; 
                                line_number++;
                            }
                        }
                        stock_list[stock].insert(latest);
                    }
                }
                line_number++;
            } else {
                // Clear only the end-of-file flag
                inputFile.clear();
                inputFile.seekg(0); // Seek to the beginning of the file
                last_line_number = line_number;
                line_number = 0;
                break;
            }
        }
    return 0;
}

int trader(std::string *message)
{
    return 1;
}

// void* userThread(void* arg)
// {
//     int thread_id = *(int*)arg;
//     while(true)
//     {
//         int currentTime;
//         {
//             currentTime = commonTimer.load();
//         }
//         int end = reader(currentTime);
//         if (end) break;
//     }
//     return nullptr;
// }

// void* userTrader(void* arg)
// {
//     return nullptr;
// }